"use client"

import { useState, useEffect } from "react"
import { MessageCircle, X, Send, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<{ text: string; isUser: boolean }[]>([
    { text: "Olá! Como posso ajudá-lo hoje?", isUser: false },
  ])
  const [newMessage, setNewMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  // Função para iniciar chat no WhatsApp
  const startWhatsAppChat = (message: string) => {
    const phoneNumber = "924723008"
    const encodedMessage = encodeURIComponent(message)
    window.open(`https://wa.me/${phoneNumber}?text=${encodedMessage}`, "_blank")
  }

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    // Adicionar mensagem do usuário
    const userMessage = newMessage.trim()
    setMessages((prev) => [...prev, { text: userMessage, isUser: true }])
    setNewMessage("")

    // Simular resposta do bot
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      setMessages((prev) => [
        ...prev,
        {
          text: "Obrigado pelo seu contato! Vou transferir você para nosso suporte via WhatsApp para um atendimento mais personalizado.",
          isUser: false,
        },
      ])

      // Aguardar um pouco e então abrir o WhatsApp
      setTimeout(() => {
        startWhatsAppChat(userMessage)
      }, 1500)
    }, 1000)
  }

  // Scroll para o fim da conversa quando mensagens são adicionadas
  useEffect(() => {
    const chatContainer = document.getElementById("chat-messages")
    if (chatContainer) {
      chatContainer.scrollTop = chatContainer.scrollHeight
    }
  }, [messages])

  return (
    <>
      {/* Botão flutuante do chat */}
      <div className="fixed bottom-6 right-6 z-50">
        {!isOpen && (
          <Button
            onClick={() => setIsOpen(true)}
            className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90 shadow-lg transition-transform hover:scale-105 flex items-center justify-center"
          >
            <MessageCircle className="h-7 w-7" />
          </Button>
        )}

        {/* Container do chat */}
        {isOpen && (
          <div className="bg-white rounded-2xl shadow-2xl w-80 sm:w-96 overflow-hidden flex flex-col border animate-fade-in">
            {/* Header do chat */}
            <div className="bg-primary text-white p-4 flex justify-between items-center">
              <div className="flex items-center">
                <MessageCircle className="h-5 w-5 mr-2" />
                <h3 className="font-medium text-lg">Chat de Atendimento</h3>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="h-8 w-8 rounded-full text-white hover:bg-primary/90"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Mensagens */}
            <div id="chat-messages" className="flex-1 overflow-y-auto p-4 h-80 space-y-4">
              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.isUser ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl ${
                      msg.isUser ? "bg-primary text-white rounded-br-none" : "bg-gray-100 text-gray-800 rounded-bl-none"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 text-gray-800 p-3 rounded-2xl rounded-bl-none flex items-center">
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Digitando...
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="border-t p-3 flex">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Digite sua mensagem..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-l-full focus:outline-none focus:ring-2 focus:ring-primary"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSendMessage()
                  }
                }}
              />
              <Button
                onClick={handleSendMessage}
                className="bg-primary hover:bg-primary/90 rounded-r-full rounded-l-none px-4"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  )
}

