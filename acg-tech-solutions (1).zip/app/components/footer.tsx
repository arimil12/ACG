import Link from "next/link"
import { Phone, Mail, Facebook, Instagram, Linkedin, Laptop, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 pt-12 pb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center gap-2 text-white font-bold text-lg mb-4">
              <Laptop className="h-5 w-5" />
              <span>ACG Tech Solutions</span>
            </Link>
            <p className="mb-4 text-gray-400 text-sm">
              Soluções tecnológicas inovadoras para empresas de todos os tamanhos. Nosso compromisso é fornecer serviços
              de alta qualidade com foco na satisfação do cliente.
            </p>
          </div>

          <div>
            <h3 className="text-base font-semibold mb-4 text-white">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="hover:text-primary transition-colors">
                  Página Inicial
                </Link>
              </li>
              <li>
                <Link href="/sobre" className="hover:text-primary transition-colors">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  Serviços
                </Link>
              </li>
              <li>
                <Link href="/contato" className="hover:text-primary transition-colors">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-base font-semibold mb-4 text-white">Serviços</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  CCTV e Segurança
                </Link>
              </li>
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  Redes de Computadores
                </Link>
              </li>
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  Manutenção e Suporte
                </Link>
              </li>
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  Software e Sistemas
                </Link>
              </li>
              <li>
                <Link href="/servicos" className="hover:text-primary transition-colors">
                  Suporte Técnico em TI
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-base font-semibold mb-4 text-white">Contato</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start">
                <Phone className="mr-3 text-primary mt-1" size={16} />
                <span>924 723 008 / 956 102 866</span>
              </li>
              <li className="flex items-start">
                <Mail className="mr-3 text-primary mt-1" size={16} />
                <span>acgtechsolutions@gmail.com</span>
              </li>
              <li className="flex items-start">
                <MapPin className="mr-3 text-primary mt-1" size={16} />
                <span>Luanda, Angola, Morro Bento</span>
              </li>
            </ul>

            <div className="mt-6">
              <h3 className="text-base font-semibold mb-3 text-white">Redes Sociais</h3>
              <div className="flex space-x-4">
                <Link href="#" className="bg-gray-800 p-2 rounded-full text-white hover:bg-primary transition-colors">
                  <Facebook size={18} />
                </Link>
                <Link href="#" className="bg-gray-800 p-2 rounded-full text-white hover:bg-primary transition-colors">
                  <Instagram size={18} />
                </Link>
                <Link href="#" className="bg-gray-800 p-2 rounded-full text-white hover:bg-primary transition-colors">
                  <Linkedin size={18} />
                </Link>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} ACG Tech Solutions - Todos os direitos reservados.</p>
          <p className="mt-2">
            <Link href="/termos" className="hover:text-primary transition-colors">
              Termos de Uso
            </Link>{" "}
            |
            <Link href="/privacidade" className="hover:text-primary transition-colors ml-2">
              Política de Privacidade
            </Link>
          </p>
        </div>
      </div>
    </footer>
  )
}

