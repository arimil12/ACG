"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Laptop } from "lucide-react"

export default function Header() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        scrolled ? "bg-white/95 backdrop-blur-sm shadow-sm" : "bg-white"
      }`}
    >
      <div className="container mx-auto py-4 flex justify-between items-center">
        <Link
          href="/"
          className="text-lg md:text-xl font-bold text-primary flex items-center gap-2 transition-transform duration-300 hover:scale-105"
        >
          <Laptop className="h-5 w-5" />
          <span>ACG Tech Solutions</span>
        </Link>
        <nav>
          <ul className="flex space-x-6 md:space-x-8 text-sm md:text-base">
            <NavLink href="/">Início</NavLink>
            <NavLink href="/sobre">Sobre</NavLink>
            <NavLink href="/servicos">Serviços</NavLink>
            <NavLink href="/contato">Contato</NavLink>
          </ul>
        </nav>
      </div>
    </header>
  )
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <li>
      <Link
        href={href}
        className="text-gray-600 hover:text-primary relative py-1 transition-colors duration-300 after:absolute after:left-0 after:bottom-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all hover:after:w-full"
      >
        {children}
      </Link>
    </li>
  )
}

