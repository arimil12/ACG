import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Network, Cpu, Code, HeadphonesIcon, ChevronRight, ArrowRight } from "lucide-react"
import type React from "react"
import Link from "next/link"
import Image from "next/image"

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-primary text-primary-foreground py-20">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/20 to-transparent"></div>
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=500&width=1000')] bg-cover bg-center opacity-10"></div>

        <div className="container relative mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in">
            Inovação, Segurança e Suporte ao seu Alcance
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-3xl mx-auto animate-fade-in animate-delay-100">
            Soluções tecnológicas completas para sua empresa, com a qualidade e confiabilidade que seu negócio merece
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in animate-delay-200">
            <Link href="/contato">
              <Button variant="default" size="lg" className="bg-white text-primary hover:bg-gray-100">
                Contate-nos
              </Button>
            </Link>
            <Link href="/servicos">
              <Button
                variant="default"
                size="lg"
                className="bg-primary text-white border border-white hover:bg-primary/90"
              >
                Saiba Mais
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section bg-gray-50">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-4 text-center">Nossos Serviços</h2>
          <p className="text-base md:text-lg text-gray-600 mb-8 text-center max-w-3xl mx-auto">
            Oferecemos soluções completas em tecnologia para atender às necessidades específicas do seu negócio
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard
              icon={<Shield className="w-8 h-8 text-primary" />}
              title="CCTV e Segurança"
              description="Sistemas de vigilância e monitoramento para sua segurança"
            />
            <ServiceCard
              icon={<Network className="w-8 h-8 text-primary" />}
              title="Redes de Computadores"
              description="Instalação e configuração de redes empresariais"
            />
            <ServiceCard
              icon={<Cpu className="w-8 h-8 text-primary" />}
              title="Manutenção de Computadores"
              description="Suporte técnico e manutenção preventiva"
            />
            <ServiceCard
              icon={<Code className="w-8 h-8 text-primary" />}
              title="Software e Sistemas"
              description="Instalação e configuração de sistemas operacionais"
            />
            <ServiceCard
              icon={<HeadphonesIcon className="w-8 h-8 text-primary" />}
              title="Suporte Técnico em TI"
              description="Assistência técnica especializada"
            />
          </div>

          <div className="mt-10 text-center">
            <Link href="/servicos">
              <Button variant="outline" className="group">
                Ver todos os serviços
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="section">
        <div className="container">
          <h2 className="text-2xl md:text-3xl font-bold mb-4 text-center">Por Que Escolher a ACG Tech Solutions?</h2>
          <p className="text-base md:text-lg text-gray-600 mb-8 text-center max-w-3xl mx-auto">
            Somos especialistas em tecnologia com anos de experiência no mercado
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <Image
                src="/placeholder.svg"
                alt="Equipe ACG Tech Solutions"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-bold">01</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Profissionais Qualificados</h3>
                  <p className="text-gray-600">
                    Nossa equipe é formada por profissionais experientes e dedicados, prontos para enfrentar os desafios
                    do mundo digital.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-bold">02</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Soluções Personalizadas</h3>
                  <p className="text-gray-600">
                    Desenvolvemos soluções sob medida para atender às necessidades específicas do seu negócio.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-bold">03</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Suporte Contínuo</h3>
                  <p className="text-gray-600">
                    Oferecemos suporte técnico contínuo para garantir que seus sistemas funcionem perfeitamente.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="section bg-gray-50">
        <div className="container">
          <div className="bg-white rounded-lg shadow-lg p-8 md:p-10 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4 text-center">Pronto para Transformar sua Tecnologia?</h2>
            <p className="text-lg mb-6 text-gray-600 text-center">
              Entre em contato conosco hoje mesmo e descubra como podemos ajudar seu negócio
            </p>
            <div className="flex justify-center">
              <Link href="/contato">
                <Button variant="default" size="lg" className="bg-primary hover:bg-primary/90">
                  Fale Conosco
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function ServiceCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <Card className="card-hover border shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex flex-col items-start">
            {icon}
            <CardTitle className="mt-3 text-lg">{title}</CardTitle>
          </div>
          <ChevronRight className="text-gray-300" />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600 text-sm">{description}</p>
      </CardContent>
    </Card>
  )
}

