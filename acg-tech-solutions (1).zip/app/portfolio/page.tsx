import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const projects = [
  {
    title: "Sistema de Segurança para Empresa X",
    description: "Implementação de um sistema de CCTV completo com 50 câmeras e monitoramento 24/7.",
    image: "/placeholder.svg",
    tags: ["CCTV", "Segurança"],
  },
  {
    title: "Rede Corporativa para Startup Y",
    description:
      "Instalação e configuração de rede para uma startup em crescimento, incluindo Wi-Fi de alta velocidade e VPN.",
    image: "/placeholder.svg",
    tags: ["Redes", "Wi-Fi", "VPN"],
  },
  {
    title: "Suporte de TI para Escola Z",
    description:
      "Fornecimento de suporte técnico contínuo e manutenção de laboratórios de informática para uma escola local.",
    image: "/placeholder.svg",
    tags: ["Suporte", "Educação"],
  },
  // Adicione mais projetos conforme necessário
]

export default function PortfolioPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Nosso Portfólio</h1>
      <p className="text-xl text-center mb-12">
        Conheça alguns dos projetos que realizamos e como ajudamos nossos clientes a alcançar seus objetivos
        tecnológicos.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, index) => (
          <Card key={index}>
            <Image
              src={project.image || "/placeholder.svg"}
              alt={project.title}
              width={400}
              height={200}
              className="w-full h-48 object-cover"
            />
            <CardHeader>
              <CardTitle>{project.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="mb-4">{project.description}</CardDescription>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag, tagIndex) => (
                  <span key={tagIndex} className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

