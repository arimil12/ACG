import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, Mail, MapPin } from "lucide-react"

export default function ContatoPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Entre em Contato</h1>
      <p className="text-xl text-center mb-12 text-gray-600">Estamos prontos para atender suas necessidades</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Envie-nos uma mensagem</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div>
                <label htmlFor="nome" className="block text-lg font-medium text-gray-700 mb-1">
                  Nome
                </label>
                <Input id="nome" placeholder="Seu nome" className="w-full" />
              </div>
              <div>
                <label htmlFor="email" className="block text-lg font-medium text-gray-700 mb-1">
                  E-mail
                </label>
                <Input id="email" type="email" placeholder="Seu e-mail" className="w-full" />
              </div>
              <div>
                <label htmlFor="assunto" className="block text-lg font-medium text-gray-700 mb-1">
                  Assunto
                </label>
                <Input id="assunto" placeholder="Assunto da mensagem" className="w-full" />
              </div>
              <div>
                <label htmlFor="mensagem" className="block text-lg font-medium text-gray-700 mb-1">
                  Mensagem
                </label>
                <Textarea id="mensagem" placeholder="Sua mensagem" className="w-full" rows={5} />
              </div>
              <Button type="submit" className="w-full">
                Enviar Mensagem
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-2xl">Informações de Contato</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center">
              <Phone className="mr-4 text-primary" size={24} />
              <div>
                <h3 className="font-medium text-lg">Telefone</h3>
                <p className="text-gray-600">924 723 008 / 956 102 866</p>
              </div>
            </div>
            <div className="flex items-center">
              <Mail className="mr-4 text-primary" size={24} />
              <div>
                <h3 className="font-medium text-lg">E-mail</h3>
                <p className="text-gray-600">acgtechsolutions@gmail.com</p>
              </div>
            </div>
            <div className="flex items-center">
              <MapPin className="mr-4 text-primary" size={24} />
              <div>
                <h3 className="font-medium text-lg">Endereço</h3>
                <p className="text-gray-600">Luanda, Angola</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

