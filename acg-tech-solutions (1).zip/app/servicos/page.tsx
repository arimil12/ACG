import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Network, Cpu, Code, HeadphonesIcon, ChevronRight } from "lucide-react"

const services = [
  {
    icon: <Shield className="w-10 h-10 text-primary" />,
    title: "CCTV e Segurança Eletrônica",
    description: "Sistemas de vigilância e segurança de última geração para proteger seu negócio.",
    details: "Instalação de câmeras de segurança, sistemas de alarme, controle de acesso e monitoramento remoto.",
  },
  {
    icon: <Network className="w-10 h-10 text-primary" />,
    title: "Redes de Computadores",
    description: "Planejamento e instalação de redes empresariais eficientes e seguras.",
    details: "Configuração de redes locais e sem fio, implementação de VPNs, e otimização de infraestrutura de rede.",
  },
  {
    icon: <Cpu className="w-10 h-10 text-primary" />,
    title: "Manutenção e Suporte de Computadores",
    description: "Serviços de manutenção e suporte para manter seu hardware funcionando perfeitamente.",
    details: "Diagnóstico e reparo de hardware, upgrades de componentes, e manutenção preventiva de equipamentos.",
  },
  {
    icon: <Code className="w-10 h-10 text-primary" />,
    title: "Software e Sistemas Operacionais",
    description: "Instalação e configuração de sistemas operacionais e softwares empresariais.",
    details:
      "Implementação de soluções de software personalizadas, atualizações de sistema e gerenciamento de licenças.",
  },
  {
    icon: <HeadphonesIcon className="w-10 h-10 text-primary" />,
    title: "Suporte Técnico em TI",
    description: "Suporte técnico especializado para todas as suas necessidades de TI.",
    details: "Assistência remota e presencial, resolução de problemas de software e hardware, e consultoria em TI.",
  },
]

export default function ServicosPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Nossos Serviços</h1>
      <p className="text-xl text-center mb-12 text-gray-600">
        Oferecemos uma gama completa de soluções em tecnologia para atender às necessidades do seu negócio.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {services.map((service, index) => (
          <Card key={index} className="border shadow-sm hover:shadow-md transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex flex-col items-start">
                  {service.icon}
                  <CardTitle className="mt-4 text-xl">{service.title}</CardTitle>
                </div>
                <ChevronRight className="text-gray-300" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-gray-600">{service.description}</p>
              <p className="text-sm text-gray-500">{service.details}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

