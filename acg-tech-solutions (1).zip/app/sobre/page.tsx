import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function SobrePage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Sobre Nós - ACG Tech Solutions</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="space-y-4">
          <p className="text-justify">
            Na <strong>ACG Tech Solutions</strong>, somos apaixonados por tecnologia e comprometidos em fornecer
            soluções inovadoras que atendam às necessidades dos nossos clientes. Fundada com a missão de oferecer
            serviços de alta qualidade em tecnologia da informação, nos destacamos como um parceiro confiável para
            empresas e indivíduos que buscam eficiência, segurança e suporte técnico de excelência.
          </p>
          <p className="text-justify">
            Nossa equipe é formada por profissionais experientes e dedicados, prontos para enfrentar os desafios do
            mundo digital. Atuamos em áreas essenciais como <strong>CCTV e Segurança Eletrônica</strong>,{" "}
            <strong>Redes de Computadores</strong>, <strong>Manutenção e Suporte de Computadores</strong>,{" "}
            <strong>Software e Sistemas Operacionais</strong> e <strong>Suporte Técnico em TI</strong>. Cada serviço é
            cuidadosamente projetado para garantir resultados confiáveis, otimizados e alinhados às expectativas dos
            nossos clientes.
          </p>
        </div>
        <div className="flex justify-center items-center">
          <Image
            src="/placeholder.svg"
            alt="Equipe ACG Tech Solutions"
            width={500}
            height={300}
            className="rounded-lg shadow-lg"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <Card>
          <CardHeader>
            <CardTitle>Missão</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-justify">
              Transformar a tecnologia em uma aliada estratégica para o sucesso de nossos clientes, oferecendo soluções
              personalizadas e inovadoras.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Visão</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-justify">
              Ser reconhecida como a principal referência em serviços de TI e segurança eletrônica em Angola,
              proporcionando resultados que superem expectativas e construam relações duradouras.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Valores</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Inovação:</strong>{" "}
                <span className="text-justify">Estamos sempre atualizados com as últimas tendências tecnológicas.</span>
              </li>
              <li>
                <strong>Excelência:</strong>{" "}
                <span className="text-justify">Buscamos a perfeição em cada projeto realizado.</span>
              </li>
              <li>
                <strong>Confiança:</strong>{" "}
                <span className="text-justify">Construímos parcerias baseadas em ética e transparência.</span>
              </li>
              <li>
                <strong>Compromisso:</strong>{" "}
                <span className="text-justify">Nossa prioridade é a satisfação e o sucesso dos nossos clientes.</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <p className="text-xl font-semibold mb-4">Convidamos você a fazer parte dessa jornada tecnológica conosco.</p>
        <p className="text-2xl font-bold text-primary">Na ACG Tech Solutions, a inovação está ao seu alcance!</p>
      </div>
    </div>
  )
}

